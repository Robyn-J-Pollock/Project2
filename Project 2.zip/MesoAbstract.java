/**
 * @author Mohammad Mukhtaruzzaman
 * @version 2019-09-18
*/
public abstract class MesoAbstract 
{
	//Abstract method calAverage to return integer array.
	abstract int[] calAverage();

	//TODO: Create an abstract method letterAverage with return type char
	
}
